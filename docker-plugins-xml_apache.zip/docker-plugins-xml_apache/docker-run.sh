#!/bin/bash

echo -e "\nApplying environment..."
. docker-compose.env

echo -e "\nAttempting to shutdown any existing containers/volumes..."
docker-compose down -v

set -e

echo -e "\nRunning detached containers..."
docker-compose up -d

if [ "$1" == "load" ]; then
  echo -e "\nRemotely loading test plugins..."
  sleep 5
  ./repo-updater/plugins-xml/test/remote-load-test-plugins.sh boundless.test
fi
