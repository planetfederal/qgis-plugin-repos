#!/bin/sh

set -e

# NOTE: user ID should match ID of the SSH user on the os-services container
adduser --system --disabled-password --ingroup users --shell /bin/false --uid 105 ${SSH_USER}

mkdir -p /var/www/html
touch /var/www/html/index.html

# Set up skeleton of plugin repo, to be overlaid with httpd-data volume
mkdir -p /var/www/qgis
mkdir -p /var/www/qgis-dev

chmod -R 0755 /var/www
chown -R ${SSH_USER}:users /var/www


# Enable apache sites
SERVER_CONF=/etc/apache2

cd $SERVER_CONF/htpasswd
mv htpasswd-qgis .htpasswd-qgis
mv htpasswd-qgis-dev .htpasswd-qgis-dev
# chmod o-rwx .htpasswd-qgis*

cd $SERVER_CONF/user
mv domain-tld-auth.conf "${DOMAIN_TLD}-auth.conf"
mv domain-tld-ssl.conf "${DOMAIN_TLD}-ssl.conf"

QGIS_CONF="${DOMAIN_TLD}.conf"
QGIS_CONF_DEV="${DOMAIN_TLD_DEV}.conf"

cd $SERVER_CONF/sites-available

mv domain-tld.conf $QGIS_CONF
mv domain-tld-dev.conf $QGIS_CONF_DEV

sed -i "s/domain-tld/${DOMAIN_TLD}/g" $QGIS_CONF

sed -i "s/domain-tld-dev/${DOMAIN_TLD_DEV}/g" $QGIS_CONF_DEV
sed -i "s/domain-tld/${DOMAIN_TLD}/g" $QGIS_CONF_DEV

cd $SERVER_CONF
mkdir conf-enabled
while IFS= read -r line; do
  ln -fs ../conf-available/${line} conf-enabled/${line}
done <conf-enabled.txt

mkdir mods-enabled
while IFS= read -r line; do
  ln -fs ../mods-available/${line} mods-enabled/${line}
done <mods-enabled.txt

sed -i "s/domain-tld-dev/${DOMAIN_TLD_DEV}/g" sites-enabled.txt
sed -i "s/domain-tld/${DOMAIN_TLD}/g" sites-enabled.txt
mkdir sites-enabled
while IFS= read -r line; do
  ln -fs ../sites-available/${line} sites-enabled/${line}
done <sites-enabled.txt

# chgrp -R www-data $SERVER_CONF
