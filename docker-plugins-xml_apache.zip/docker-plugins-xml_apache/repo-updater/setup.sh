#!/bin/sh

set -e

# NOTE: user ID should match ID of the SSH user on the os-services container
adduser --system --disabled-password --ingroup users --shell /bin/false --uid 105 ${SSH_USER}

PLUGINS_XML=/opt/repo-updater/plugins-xml
UPDATE_SCRIPT=$PLUGINS_XML/update-plugins-xml.py
UPDATE_WRAPPER=$PLUGINS_XML/update-plugins-xml.sh

mkdir -p /var/www
mkdir -p /opt/repo-updater/uploads

sed -i "s@= WEB_BASE_TEST@= '/var/www'@g" ${UPDATE_SCRIPT}

sed -i "s@= UPLOAD_BASE_TEST@= '/opt/repo-updater'@g" ${UPDATE_SCRIPT}

sed -i "s@= UPLOADED_BY_TEST@= '${UPLOADED_BY}'@g" ${UPDATE_SCRIPT}

sed -i "s@= DOMAIN_TLD_TEST@= '${DOMAIN_TLD}'@g" ${UPDATE_SCRIPT}

sed -i "s@= DOMAIN_TLD_DEV_TEST@= '${DOMAIN_TLD_DEV}'@g" ${UPDATE_SCRIPT}

sed -i "s@venv@../venv@g" ${UPDATE_WRAPPER}

chown -R ${SSH_USER}:users /opt/repo-updater
