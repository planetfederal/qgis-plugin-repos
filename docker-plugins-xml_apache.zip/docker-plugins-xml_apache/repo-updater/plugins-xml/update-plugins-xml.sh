#!/bin/bash

set -e

# Wrapper script for activating Python virtenv and running update-plugins-xml.py

if [ $# -eq 0 ]; then
  echo "Usage: $0 [--dev] [--auth] some-plugin.zip"
  exit 1
fi

# parent directory of script
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)

cd "${SCRIPT_DIR}"

. "venv/bin/activate"

./update-plugins-xml.py "$@"
