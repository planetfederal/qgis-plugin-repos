#!/usr/bin/env python

# -*- coding: utf-8 -*-
"""
/***************************************************************************
 update-plugins-xml.py

 Command line utility to generate/update a QGIS plugin repo's plugins.xml
                             -------------------
        begin                : 2016-02-22
        git sha              : $Format:%H$
        copyright            : (C) 2016 by
                               Larry Shaffer/Boundless Spatial Inc.
        email                : lshaffer@boundlessgeo.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import argparse
import codecs
import ConfigParser
import datetime
import os
import pprint
import re
import shutil
import StringIO
import sys
import tempfile
import zipfile

from lxml import etree

SCRIPT_DIR = os.path.dirname(__file__)
WEB_BASE_TEST = os.path.join(SCRIPT_DIR, 'www')
UPLOAD_BASE_TEST = SCRIPT_DIR
UPLOADED_BY_TEST = "Boundless"
DOMAIN_TLD_TEST = "boundless-test"
DOMAIN_TLD_DEV_TEST = "boundless-test-dev"

# FIXME: on deploy, assign correct base locations, uploader and domains
WEB_BASE = WEB_BASE_TEST
# UPLOAD_BASE should not be --dev or --auth dependent, and be outside www
UPLOAD_BASE = UPLOAD_BASE_TEST
UPLOADED_BY = UPLOADED_BY_TEST
DOMAIN_TLD = DOMAIN_TLD_TEST
DOMAIN_TLD_DEV = DOMAIN_TLD_DEV_TEST


class Error(Exception):
    """Base class for exceptions in this module."""
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


class ValidationError(Error):
    pass


class XmlError(Error):
    pass


class QgisRepo(object):

    def __init__(self, args):
        self.args = args
        self.plugins_subdir = "plugins"
        self.dev_suffix = '-dev' if args.dev else ''
        self.auth_suffix = "-auth" if args.auth else ''
        self.web_subdir = "qgis{0}".format(self.dev_suffix)
        self.web_dir = os.path.join(WEB_BASE, self.web_subdir)
        self.web_plugins_dir = os.path.join(self.web_dir, self.plugins_subdir)
        self.repo_url = 'http{0}://{1}'.format(
            's' if args.auth else '',
            DOMAIN_TLD_DEV if args.dev else DOMAIN_TLD)
        self.upload_dir = os.path.join(UPLOAD_BASE, 'uploads')
        self.max_upload_size = 512000000  # 512 MB
        self.template_dir = os.path.join(SCRIPT_DIR, "templates")

        self.packages_subdir = "packages{0}".format(self.auth_suffix)
        self.packages_dir = os.path.join(
            self.web_plugins_dir, self.packages_subdir)
        self.web_icon_dir = "icons"  # relative to plugins.xml
        self.icons_dir = os.path.join(self.web_plugins_dir, self.web_icon_dir)
        self.default_icon = 'default.png'
        self.web_default_icon = os.path.join(
            self.web_icon_dir, self.default_icon)
        self.plugins_xml_name = 'plugins.xml'
        self.plugins_xml = os.path.join(
            self.web_plugins_dir, self.plugins_xml_name)
        self.plugins_xml_tmpl = 'plugins.xml'
        self.plugins_xsl_name = 'plugins.xsl'
        self.plugins_xsl = os.path.join(
            self.web_plugins_dir, self.plugins_xsl_name)
        self.plugins_xsl_tmpl = 'plugins{0}.xsl'.format(self.dev_suffix)
        self.index_root_tmpl = 'index{0}_root.html'.format(self.dev_suffix)
        self.index_blank_tmpl = 'index_blank.html'
        self.favicon_tmpl = 'favicon.ico'

    def dump_attributes(self, echo=False):
        txt = 'args: {0}\n'.format(self.args)
        attrs = [
            'web_subdir',
            'web_dir',
            'repo_url',
            'upload_dir',
            'max_upload_size',
            'template_dir',
            'packages_subdir',
            'packages_dir',
            'icons_dir',
            'web_default_icon',
            'plugins_xml'
        ]
        for a in attrs:
            txt += '{0}: {1}\n'.format(a, self.__getattribute__(a))
        if echo:
            print(txt)
        return txt

    def setup_repo(self):
        # set up web dir
        if not os.path.exists(self.web_dir):
            os.makedirs(self.web_dir)

        # set up default root web contents, if needed
        root_index = os.path.join(self.web_dir, 'index.html')
        if not os.path.exists(root_index):
            shutil.copyfile(
                os.path.join(self.template_dir, self.index_root_tmpl),
                root_index)

        favicon = os.path.join(self.web_dir, self.favicon_tmpl)
        if not os.path.exists(favicon):
            shutil.copyfile(
                os.path.join(self.template_dir, self.favicon_tmpl), favicon)

        # set up web plugins dir
        if not os.path.exists(self.web_plugins_dir):
            os.makedirs(self.web_plugins_dir)

        # no index of web plugins dir
        plugins_index = os.path.join(self.web_plugins_dir, 'index.html')
        if not os.path.exists(plugins_index):
            shutil.copyfile(
                os.path.join(self.template_dir, self.index_blank_tmpl),
                plugins_index)

        # set up default plugins.xml, if needed
        if not os.path.exists(self.plugins_xml):
            shutil.copyfile(
                os.path.join(self.template_dir, self.plugins_xml_tmpl),
                self.plugins_xml)

        # set up default plugins.xsl, if needed
        if not os.path.exists(self.plugins_xsl):
            shutil.copyfile(
                os.path.join(self.template_dir, self.plugins_xsl_tmpl),
                self.plugins_xsl)

        # set up packages dir
        if not os.path.exists(self.packages_dir):
            os.makedirs(self.packages_dir)

        # set up icons dir
        if not os.path.exists(self.icons_dir):
            os.makedirs(self.icons_dir)

        # setup default plugin icon
        default_icon_file = os.path.join(self.icons_dir, self.default_icon)
        if not os.path.exists(default_icon_file):
            shutil.copyfile(
                os.path.join(self.template_dir, self.default_icon),
                default_icon_file)

    def update_plugins_xml(self, plugin):
        # parse plugins.xml
        parser = etree.XMLParser(strip_cdata=False, remove_blank_text=True)
        plugins_tree = etree.parse(self.plugins_xml, parser)
        """:type: etree._ElementTree"""
        # docinfo = plugins_tree.docinfo
        # """:type: etree.DocInfo"""
        # print(etree.tostring(plugins_tree, pretty_print=True))

        plugins = plugins_tree.getroot()
        """:type: etree._Element"""
        existing_plugins = plugins.findall(
            "pyqgis_plugin[@name='{0}']".format(plugin.metadata["name"]))

        for p in existing_plugins:
            plugins.remove(p)
        # print(etree.tostring(plugins_tree, pretty_print=True))

        plugins.append(plugin.pyqgis_plugin_element())

        # write out plugins.xml
        xml = etree.tostring(
            plugins_tree, pretty_print=True, method="xml",
            encoding='UTF-8', xml_declaration=True)
        # print(xml)

        with open(self.plugins_xml, 'w') as f:
            f.write(xml)


class QgisPlugin(object):

    def __init__(self, args, repo):
        self.args = args
        self.repo = repo
        """:type: QgisRepo"""
        self.zip_path = os.path.join(self.repo.upload_dir, args.zip_name)
        self.required_metadata = (
            'name', 'description', 'version', 'qgisMinimumVersion', 'author',
            'about', 'tracker', 'repository'
        )
        self.optional_metadata = (
            'homepage', 'changelog', 'qgisMaximumVersion', 'tags', 'deprecated',
            'experimental', 'external_deps', 'server', 'email'
        )
        self.boolean_metadata = ('deprecated', 'experimental', 'server')
        self.cdata_metadata = (
            'about', 'author_name', 'changelog', 'description', 'repository',
            'tracker', 'uploaded_by'
        )

        self.auth_suffix = \
            ' (AUTHENTICATED DOWNLOAD)' if self.args.auth else ''

        # undefined until validated
        self.package_name = None
        self.metadata = None

        self._validate()

    def dump_attributes(self, echo=False):
        txt = 'package_name: {0}\n'.format(self.package_name)
        pp = pprint.PrettyPrinter(indent=2)
        txt += 'metadata: \n{0}\n'.format(pp.pprint(self.metadata))
        if echo:
            print(txt)
        return txt

    def setup_plugin(self):
        self._extract_icon()
        self._move_plugin_archive()

    def _validate(self):
        # verify archive and get metadata
        try:
            self._validate_archive()
            self.metadata = dict(self._validate_metadata())
            # print metadata
        except ValidationError, e:
            msg = unicode('Not a valid plugin ZIP archive')
            raise ValidationError("{0}: {1}".format(msg, e))

    def _validate_archive(self):
        """
       Analyzes a plugin's ZIP archive
       Current checks:
         * archive path is absolute
         * archive size <= self.repo.max_upload_size
         * archive is readable
         * archive does not have security issues
       """
        self.zip_path = os.path.realpath(self.zip_path)
        if not os.path.isabs(self.zip_path) \
                or not os.path.exists(self.zip_path):
            raise ValidationError(
                "ZIP archive can not be resolved to an existing absolute path.")

        fsize = os.path.getsize(self.zip_path)
        if fsize > self.repo.max_upload_size:
            raise ValidationError(
                "ZIP archive is too big at ({0}) Bytes. Max size is {1} Bytes"
                .format(fsize, self.repo.max_upload_size))

        try:
            zip_obj = zipfile.ZipFile(self.zip_path)
        except:
            raise ValidationError("Could not unzip archive.")
        for zname in zip_obj.namelist():
            if zname.find('..') != -1 or zname.find(os.path.sep) == 0:
                raise ValidationError(
                    "For security reasons, ZIP archive cannot contain paths")
        bad_file = zip_obj.testzip()
        zip_obj.close()
        del zip_obj
        if bad_file:
            try:
                raise ValidationError(
                    'Bad ZIP (maybe a CRC error) on file {0}'.format(bad_file))
            except UnicodeDecodeError:
                raise ValidationError(
                    'Bad ZIP (maybe unicode filename) on file {0}'
                    .format(unicode(bad_file, errors='replace')))

    def _validate_metadata(self):
        """
        Analyzes a zipped file, returns metadata if success, False otherwise.
        Current checks:
          * zip contains __init__.py in first level dir
          * mandatory metadata: self.required_metadata
          * package_name regexp: [A-Za-z][A-Za-z0-9-_]+
          * author regexp: [^/]+
        """
        try:
            zip_obj = zipfile.ZipFile(self.zip_path)
        except:
            raise ValidationError("Could not unzip file.")

        # Checks that package_name exists
        namelist = zip_obj.namelist()
        try:
            package_name = namelist[0][:namelist[0].index('/')]
        except:
            raise ValidationError(
                'Cannot find a folder inside the compressed package:'
                'this does not seems a valid plugin')

        # Cuts the trailing slash
        if package_name.endswith('/'):
            package_name = package_name[:-1]
        initname = package_name + '/__init__.py'
        metadataname = package_name + '/metadata.txt'
        if initname not in namelist and metadataname not in namelist:
            raise ValidationError(
                'Cannot find __init__.py or metadata.txt in the ZIP package:'
                'this does not seems a valid plugin'
                '(searched for {0} and {1})'.format(initname, metadataname))

        # Checks for __init__.py presence
        if initname not in namelist:
            raise ValidationError("Cannot find __init__.py in plugin package")

        # Checks metadata
        metadata = []
        # First parse metadata.txt
        if metadataname in namelist:
            try:
                parser = ConfigParser.ConfigParser()
                parser.optionxform = str
                parser.readfp(StringIO.StringIO(
                    codecs.decode(zip_obj.read(metadataname), "utf8")))
                if not parser.has_section('general'):
                    raise ValidationError(
                        "Cannot find a section named 'general' in {0}"
                        .format(metadataname))
                metadata.extend(parser.items('general'))
            except Exception, e:
                raise ValidationError("Errors parsing {0}: {1}"
                                      .format(metadataname, e))
            metadata.append(('metadata_source', 'metadata.txt'))
        else:
            raise ValidationError('Cannot find a valid metadata.txt')

        # Check for required metadata
        failed = []
        for md in self.required_metadata:
            if md not in dict(metadata) or not dict(metadata)[md]:
                failed.append(md)
        if failed:
            raise ValidationError(
                'Cannot find required metadata ({0}) in metadata source {1}'
                .format(' '.join(failed),
                        dict(metadata).get('metadata_source')))

        # Transforms booleans flags (experimental)
        for flag in self.boolean_metadata:
            if flag in dict(metadata):
                metadata[metadata.index((flag, dict(metadata)[flag]))] = \
                    (flag, dict(metadata)[flag].lower() == 'true' or
                     dict(metadata)[flag].lower() == '1')

        # Adds package_name
        if not re.match(r'^[A-Za-z][A-Za-z0-9-_]+$', package_name):
            raise ValidationError(
                "The name of top level directory inside the zip package must "
                "start with an ASCII letter and can only contain ASCII letters,"
                " digits and the signs '-' and '_'.")
        metadata.append(('package_name', package_name))
        self.package_name = package_name

        zip_obj.close()
        del zip_obj

        # Check author
        if 'author' in dict(metadata):
            if not re.match(r'^[^/]+$', dict(metadata)['author']):
                raise ValidationError("Author name cannot contain slashes.")

        # strip and check
        checked_metadata = []
        for k, v in metadata:
            try:
                if not (k in self.boolean_metadata):
                    # v.decode('UTF-8')
                    checked_metadata.append((k, v.strip()))
                else:
                    checked_metadata.append((k, v))
            except UnicodeDecodeError, e:
                raise ValidationError(
                    "There was an error converting metadata '{0}' to UTF-8. "
                    "Reported error was: {1}".format(k, e))

        return checked_metadata

    def _extract_icon(self):
        package_icon_dir = os.path.join(self.repo.icons_dir, self.package_name)
        if not os.path.exists(package_icon_dir):
            os.makedirs(package_icon_dir)

        # dump any icon file
        try:
            zip_obj = zipfile.ZipFile(self.zip_path)
            # Strip leading dir for some plugins
            if self.metadata['icon'].startswith('./'):
                icon_path = self.metadata['icon'][2:]
            else:
                icon_path = self.metadata['icon']
            tmp_dir = tempfile.mkdtemp()
            zip_icon = zip_obj.extract(
                self.package_name + '/' + icon_path, tmp_dir)
            if zip_icon and os.path.exists(zip_icon):
                fname, fext = os.path.splitext(zip_icon)
                ver_icon_path = '{0}/{1}{2}'.format(
                    package_icon_dir, self.metadata['version'], fext)

                if os.path.exists(ver_icon_path):
                    os.remove(ver_icon_path)
                shutil.move(zip_icon, ver_icon_path)
                self.metadata['plugin_icon'] = '{0}/{1}/{2}{3}'.format(
                    self.repo.web_icon_dir, self.package_name,
                    self.metadata['version'], fext)
            else:
                self.metadata['plugin_icon'] = self.repo.web_default_icon
            shutil.rmtree(tmp_dir)
        except KeyError:
            self.metadata['plugin_icon'] = self.repo.web_default_icon

    def _move_plugin_archive(self):
        package_path = os.path.join(
            self.repo.packages_dir, os.path.basename(self.zip_path))
        if os.path.exists(package_path):
            os.remove(package_path)
        shutil.copy2(self.zip_path, self.repo.packages_dir)
        self.metadata['plugin_url'] = '{0}/{1}/{2}/{3}'.format(
            self.repo.repo_url, self.repo.plugins_subdir,
            self.repo.packages_subdir, os.path.basename(self.zip_path))
        os.remove(self.zip_path)

    def wrap_cdata(self, tag, source):
        if tag is 'description' and self.auth_suffix:
            source += self.auth_suffix
        if tag in self.cdata_metadata:
            return etree.CDATA(source)
        else:
            return source

    def add_el(self, elem, tag, source, default=''):
        el = etree.SubElement(elem, tag)
        if isinstance(source, dict):
            # fixup some unequal metadata.txt -> plugins.xml mappings
            key = tag
            if tag is 'qgis_minimum_version':
                key = 'qgisMinimumVersion'
            elif tag is 'qgis_maximum_version':
                key = 'qgisMaximumVersion'
            elif tag is 'author_name':
                key = 'author'
            if key in source:
                el.text = self.wrap_cdata(tag, unicode(source[key]))
            else:
                el.text = self.wrap_cdata(tag, unicode(default))
        else:
            el.text = self.wrap_cdata(tag, unicode(source))

    def pyqgis_plugin_element(self):
        md = self.metadata
        el = etree.Element(
            "pyqgis_plugin", name=md["name"], version=md["version"])
        """:type: etree._Element"""
        self.add_el(el, 'description', md)
        self.add_el(el, 'about', md)
        self.add_el(el, 'version', md)
        self.add_el(el, 'qgis_minimum_version', md)
        self.add_el(el, 'qgis_maximum_version', md, default='2.99.0')
        self.add_el(el, 'homepage', md)
        self.add_el(el, 'file_name', os.path.basename(self.zip_path))
        self.add_el(el, 'icon', md['plugin_icon'])
        self.add_el(el, 'author_name', md)
        self.add_el(el, 'download_url', md['plugin_url'])
        self.add_el(el, 'uploaded_by', UPLOADED_BY)
        self.add_el(el, 'create_date', md)
        self.add_el(el, 'update_date', datetime.datetime.now().isoformat())
        self.add_el(el, 'experimental', md, default='False')
        self.add_el(el, 'deprecated', md, default='False')
        self.add_el(el, 'tracker', md)
        self.add_el(el, 'repository', md)
        self.add_el(el, 'changelog', md)
        self.add_el(el, 'tags', md)
        self.add_el(el, 'downloads', '0')
        self.add_el(el, 'average_vote', '0.0')
        self.add_el(el, 'rating_votes', '0')
        return el


def arg_parser():
    parser = argparse.ArgumentParser(
        description="""\
            Generate or update a QGIS plugin repo plugins.xml file.
            """
    )
    parser.add_argument(
        'zip_name',
        help='Name of uploaded ZIP archive in uploads directory'
    )
    parser.add_argument(
        '--auth',
        action='store_true',
        help='Indicates download archive needs authentication'
    )
    parser.add_argument(
        '--dev',
        action='store_true',
        help='Indicates update to qgis-dev repository'
    )
    return parser


def main():
    # get defined args
    args = arg_parser().parse_args()
    # print args

    # set up repo target dirs relative to passed args
    repo = QgisRepo(args)
    # repo.dump_attributes(echo=True)
    repo.setup_repo()

    plugin = QgisPlugin(args, repo)
    # plugin.dump_attributes(echo=True)
    plugin.setup_plugin()

    repo.update_plugins_xml(plugin)

if __name__ == '__main__':
    main()
    sys.exit(0)
