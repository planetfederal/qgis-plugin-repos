#!/bin/bash

# Locally loads the plugins into the test directories

set -e

# parent directory of script
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)

cd "${SCRIPT_DIR}/../uploads"

for zp in test_plugin_1.zip test_plugin_2.zip
do
  ../update-plugins-xml.sh $zp
  ../update-plugins-xml.sh --dev $zp
done

for zp in test_plugin_3.zip
do
  ../update-plugins-xml.sh --auth $zp
  ../update-plugins-xml.sh --dev --auth $zp
done

