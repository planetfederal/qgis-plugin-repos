## How to add or update PyQGIS plugins

The Python updater script uses the plugin's [metadata.txt][md] (embedded in the
ZIP archive) to add a new, or update an existing, plugin in the repo's
`plugins.xml` file.

Note: the required fields in [metadata.txt][md] are validated by the updater
script. Ensure your plugin's fields are correctly annotated. The one exception
is `email` address, which is not required for a simple repository setup (since
it would expose it via plain HTML).

[md]: http://docs.qgis.org/testing/en/docs/pyqgis_developer_cookbook/plugins.html#plugin-metadata

Because this is a simple `plugins.xml`-based QGIS plugin repository, the
following items are not supported in QGIS's plugin manager interface:

- Rating
- Rating votes
- Number of downloads

### To upload a ZIP archive and remotely run repo updater script

Copy a test plugin's ZIP archive up to server:

    $> scp uploads/test_plugin_1.zip boundless.test:/opt/repo-updater/uploads/

Run remote updater script on uploaded archive:

    $> ssh boundless.test "/opt/repo-updater/plugins-xml/update-plugins-xml.sh test_plugin_1.zip"

Upon updating, any existing plugin in the repo that _exactly
matches_ the plugin's name (e.g. "GeoServer Explorer") will first be removed
from the XML file. Existing download archives will not be removed. Any further
management of the `plugins.xml` file beyond this workflow will need to be done
by manual editing.

### Manual editing of the `plugins.xml`

You can log into the running `sshd` container and edit, for example:

    $ docker exec -it -t qgisrepo_sshd_1 bash -l
    root@62696a0fa3aa:/# nano /var/www/qgis/plugins/plugins.xml
