# Docker-based QGIS Plugin Repository

This orchestrated setup is for quickly standing up two HTTP(S) endpoints for
simple QGIS plugin repositories (for _release_ and _dev_), then updating them
via SSH by uploading PyQGIS plugin ZIP archives and running a Python updater
script to process the archives. It is particularly useful for processing
automated developer builds of plugins (e.g. from Jenkins or Travis CI).

Uses `docker-compose` to create images and manage their containers for:

- Service **httpd** on Debian: Apache HTTPD server on ports 80 and 443
- Service **sshd** on Debian: OpenSSH server on port 2222
- Volume **htdata** on busybox: HTTP(S) configuration and site content
- Volume **updater** on busybox: QGIS plugin repo generator/updater scripts

**IMPORTANT:** This setup requires docker 1.10+ and docker-compose 1.6+. It
_may_ work with previous versions of docker (untested), but _will not work_ with
previous versions of docker-compose.

**WARNING:** This is mostly for testing. If you use this setup for a live
production repository, you will need to do additional security hardening.

## Service and Volume Container Layout

Here are the data volume containers and their mounted directory overlays for
each running service:

- From **htdata**:
  - /usr/local/apache2/conf
  - /usr/local/apache2/htdocs
  - /var/www

- From **updater**
  - /opt/repo-updater/plugins-xml
  - /opt/repo-updater/uploads

- Service **httpd** is overlaid with **htdata** directories

- Service **sshd** is overlaid with **htdata** and **updater**  directories

## Steps to Stand Up a Test Repository

### 1. Clone repo

_Note: this setup may move from a private to public repo_

    $> git clone git@github.com:boundlessgeo/qgis-build.git
    $> cd qgis-build/plugin-repo/docker-plugins-xml

### 2. Build test images

Using [`docker-compose`](https://docs.docker.com/compose/), build the images by
_sourcing_ the custom environment first (configured for `bash` shell):

    $> . docker-compose.env

Then, build the images. See `docker-compose build --help`

    $> docker-compose build

This should give you the following similar test images:

    $> docker images
    REPOSITORY        TAG     ...  SIZE
    qgisrepo_sshd     latest  ...  342 MB
    qgisrepo_updater  latest  ...  2.266 MB
    qgisrepo_httpd    latest  ...  193.5 MB
    qgisrepo_htdata   latest  ...  1.428 MB

### 3. Run test containers

When running the containers, only the **httpd** and **sshd** service will remain
up, this is because the other containers merely provide [data volumes][dv] that
offer separation of the services from their configuration and content. This is a
general docker design idiom and allows the data volumes to be accessed
separately by multiple services, for example a service to back up the data.

[dv]: https://docs.docker.com/engine/userguide/containers/dockervolumes/

See `docker-compose up --help`

    $> docker-compose up  -d
    Starting qgisrepo_htdata_1
    Starting qgisrepo_httpd_1
    Starting qgisrepo_updater_1
    Starting qgisrepo_sshd_1

This should give you the following similar test containers:

    $> docker ps -a
    ...  IMAGE             ...  STATUS  PORTS           NAMES
    ...  qgisrepo_sshd     ...  Up      2222->2222/tcp  qgisrepo_sshd_1
    ...  qgisrepo_updater  ...  Exited                  qgisrepo_updater_1
    ...  qgisrepo_httpd    ...  Up      80->80/tcp,
                                        443->443/tcp    qgisrepo_httpd_1
    ...  qgisrepo_htdata   ...  Exited                  qgisrepo_htdata_1

### 4. Get docker machine's IP address

On Linux, the IP address is:

    $> docker inspect --format '{{ .NetworkSettings.IPAddress }}' qgisrepo_sshd_1

If using `docker-machine` on OSX and Win (or some Linux setups), docker runs in
a thin VirtualBox or VMware virtual machine and is managed by the
`docker-machine` utility, with the default machine name called 'default'.

It's IP address can be obtained with the following command:

    $> docker-machine ip $(docker-machine active)

or, if the docker machine's environment has already been sourced:

    $> docker-machine ip $DOCKER_MACHINE_NAME

### 5. Update hosts file

NOTE: if using a VM via recent versions of the `docker-machine` utility, your VM
may essentially have a _static_ local IP address.

To try out the preconfigured SSH server and wildcard test SSL certificate, add
the following to your `hosts` file:

    <docker-machine-ip> boundless.test
    <docker-machine-ip> qgis.boundless.test
    <docker-machine-ip> qgis-dev.boundless.test

### 6. Configure SSH client

Add test SSH private key to your SSH config directory:

    $> cp ssh-server/test-ssh-keypair/boundless_test_id_rsa ~/.ssh/
    $> chmod 0600 ~/.ssh/boundless_test_id_rsa

Add an SSH configuration for the boundless.test repo (see [ssh_config][sc])

    Host boundless.test
      HostName boundless.test  <-- or docker-machine's IP
      Port 2222
      User user
      IdentityFile ~/.ssh/boundless_test_id_rsa

[sc]: http://www.openssh.com/manual.html

Note: The SSH host fingerprint will change if you _rebuild_ the `sshd` image. You
will need to remove the `[boundless.test]:2222 ...` line from your
`~/.ssh/known_hosts` file, else receive a WARNING (and failed connection) using
your SSH client.


### 7. Test SSH access

Running the following should produce a similar prompt:

    $> ssh boundless.test

    The programs included with the Debian GNU/Linux system are free software;
    ...
    user@b374d2418324:~$

The default `user` has a password of `pass`, which can be used to elevate
permissions using `sudo`.

### 8. Populate the repositories with test plugins

Run the SSH-based remote loading script for the test plugins:

    $> ./repo-updater/plugins-xml/test/remote-load-test-plugins.sh
    test_plugin_1.zip     100% 2768     2.7KB/s   00:00
    ...
    test_plugin_3.zip     100% 2972     2.9KB/s   00:00

This will load 3 test plugins into both the `release` and `dev` repositories,
with `test_plugin_3` loaded as "download authenticated" restricted plugin.

Note: this also sets up some basic web files for the `release` and `dev` sites.

### 9. Test access to HTTP endpoints

Go to:

- <http://qgis.boundless.test/>
- <http://qgis-dev.boundless.test/>

Should produce a _blank page_, with no error.

Go to:

- <http://qgis.boundless.test/plugins/plugins.xml>
- <http://qgis-dev.boundless.test/plugins/plugins.xml>

Should produce a listing of 3 plugins. Each download link should download the
appropriate ZIP archive, with the `test_plugin_3.zip` download requiring
authentication:

- username: user or dev _(relative to repo)_
- password: password

### 10. Test access to HTTPS endpoints

Note: you should already have set up in your `hosts` file as noted above, else
the test SSL setup _will not function_.

Add the following concatenated certificate to your root Certificate Authorities
for your browser:

[httpd-data/resources/conf/server-ca.crt][ct]

[ct]: ./httpd-data/resources/conf/server-ca.crt

The server's certificate is signed by an issuing chain with a self-signed root
test certificate, so you need to set at least the "Boundless Test Root CA"
certificate to trusted.

Go to HTTPS URLs and verify the same results as with HTTP access above:

- <https://qgis.boundless.test/>
- <https://qgis.boundless.test/plugins/plugins.xml>
- <https://qgis-dev.boundless.test/>
- <https://qgis-dev.boundless.test/plugins/plugins.xml>

Additionally, the connection should be secured with a `*.boundless.test`
wildcard certificate and there should be no SSL errors.

## Plugin Repository Updating/Editing

See the [README for the Python updater script][us]

[us]: ./repo-updater/plugins-xml/README.md

## Customization and Deployment

Review/edit the [docker-compose.env][de] file for customization of the build
environment.

[de]: ./docker-compose.env

Edit files under [httpd-data/resources][hr] to configure **httpd** image.

[hr]: ./httpd-data/resources/

Edit files under [ssh-server/resources][ss] to configure **sshd** image.

[ss]: ./ssh-server/resources/

For iterative rebuilds of `docker-compose` (once you have a working setup), you
can use the build script:

    $> ./docker-rebuild-compose.sh

