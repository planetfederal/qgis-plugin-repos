#!/bin/bash

set -e

# DEBIAN_FRONTEND=noninteractive apt-get -qy install \
#   git \
#   python-pip \
#   python-lxml
#
# apt-get -qy clean
# apt-get -q purge

mkdir -p /opt/repo-updater
pushd /opt/repo-updater > /dev/null

    if [ ! -d venv ]; then
      pip install virtualenv
      virtualenv --system-site-packages venv
    fi
    # Install any requirements.txt
    # . venv/bin/activate
    # pip install something

popd  > /dev/null #/opt/repo-updater

mkdir -p /opt/repo-updater/uploads

chown -R ${SSH_USER}:users /opt
