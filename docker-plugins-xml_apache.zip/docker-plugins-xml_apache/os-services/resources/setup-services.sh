#!/bin/bash

set -e

cd /opt/setup

### Supervisor ###

mkdir -p /var/log/supervisor
cp services.conf /etc/supervisor/conf.d/
cat supervisord.conf > /etc/supervisor/supervisord.conf


### SSH ###

mkdir /var/run/sshd

# Set up SSH keys
mkdir -p /home/${SSH_USER}/.ssh
chmod -v 0700 /home/${SSH_USER}/.ssh
if [ -z ${SSH_PUBLIC_KEY+x} ]; then
  SSH_PUBLIC_KEY="$(cat /opt/setup/boundless_test_id_rsa.pub)"
fi
echo "${SSH_PUBLIC_KEY}" > /home/${SSH_USER}/.ssh/authorized_keys
chmod -v 0600 /home/${SSH_USER}/.ssh/authorized_keys
chown -R ${SSH_USER}:users /home/${SSH_USER}

# Set up SSH server config
cat sshd_config > /etc/ssh/sshd_config


### HTTPD ###

mkdir -p /var/lock/apache2 /var/run/apache2

cp httpd-foreground /usr/local/bin/
chmod 0700 /usr/local/bin/httpd-foreground
