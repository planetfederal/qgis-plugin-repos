#!/bin/bash

set -e

# Bug fix: https://bugs.launchpad.net/ubuntu/+source/systemd/+bug/1325142/comments/38
# dpkg-divert --local --add /etc/init.d/systemd-logind \
#  && ln -s /bin/true /etc/init.d/systemd-logind

# Avoid 'ERROR: invoke-rc.d: policy-rc.d denied execution'
# echo "#!/bin/sh\nexit 0" > /usr/sbin/policy-rc.d

# Use apt-catcher-ng caching
if [ -n "${APT_CATCHER_IP}" ]; then
  echo 'Acquire::http { Proxy "http://'${APT_CATCHER_IP}':3142"; };' >> /etc/apt/apt.conf.d/01proxy
fi

apt-get -y update
apt-get -y upgrade
DEBIAN_FRONTEND=noninteractive apt-get -y install \
  nano \
  sudo \
  git \
  supervisor \
  apache2 \
  openssh-server \
  python-pip \
  python-lxml

apt-get -q clean
apt-get -q purge

# NOTE: SSH user, so all other containers reference same uid
adduser --system --ingroup users --shell /bin/bash --uid 105 ${SSH_USER}
echo "${SSH_USER}:${SSH_USER_PASS}" | chpasswd
su -c "gpasswd -a ${SSH_USER} sudo"
